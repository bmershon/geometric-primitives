(function (global, factory) {
  typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('gl-matrix')) :
  typeof define === 'function' && define.amd ? define('gl-geom', ['exports', 'gl-matrix'], factory) :
  factory((global.gl_geom = {}),global.glMatrix);
}(this, function (exports,glMatrix) { 'use strict';

  var epsilon = 1e-6;

  //Purpose: Project vector u onto vector v using the glMatrix library
  //Inputs: u (vec3), v (vec3)
  //Returns: projv (vec3), the projection of u onto v
  function projVector(u, v) {
    var scale = (glMatrix.vec3.dot(u, v)/glMatrix.vec3.dot(v, v));//The scale in front of v is (u dot v) / (v dot v)
    var projv = glMatrix.vec3.create(); //Allocate a vector to hold the output
    glMatrix.vec3.scale(projv, v, scale); //Scale v by the appropriate amount
    return projv; //Return the result
  }

  //Purpose: To compute the perpendicular projection of a vector u onto a vector v
  //Inputs: u (vec3), v (vec3)
  //Returns: projperpv (vec3), the projection of u onto v
  function projPerpVector(u, v) {
    var projv = projVector(u, v);
    var projperpv = glMatrix.vec3.create();
    glMatrix.vec3.subtract(projperpv, u, projv);
    return projperpv;
  }

  //Purpose: To compute the angle between the vectors ab and ac
  //Inputs: a (vec3), b (vec3), c (vec3)
  //Returns: angle (radians - float)
  function getAngle(a, b, c) {
    var ab = glMatrix.vec3.create(),
        ac = glMatrix.vec3.create();
    ab = glMatrix.vec3.sub(ab, b, a);
    ac = glMatrix.vec3.sub(ac, c, a);
    var r = glMatrix.vec3.dot(ab, ac)/(glMatrix.vec3.length(ab)*glMatrix.vec3.length(ac));
    return Math.acos(r);
  }


  //Purpose: Given three 3D vertices a, b, and c, compute the area of the triangle
  //spanned by them
  //Inputs: a (vec3), b (vec3), c (vec3)
  //Returns: area (float)
  function getTriangleArea(a, b, c) {
    var out = glMatrix.vec3.create(),
        ab  = glMatrix.vec3.create(),
        ac  = glMatrix.vec3.create();
    ab = glMatrix.vec3.sub(ab, b, a);
    ac = glMatrix.vec3.sub(ac, c, a);
    out = glMatrix.vec3.cross(out, ab, ac);
    return Math.abs(glMatrix.vec3.length(out))/2.0; 
  }

  //Purpose: For a plane determined by the points a, b, and c, with the plane
  //normal determined by those points in counter-clockwise order using the
  //right hand rule, decide whether the point d is above, below, or on the plane
  //Inputs: a (vec3), b (vec3), c (vec3)
  //Returns: 1 if d is above, -1 if d is below, 0 if d is on
  function getAboveOrBelow(a, b, c, d) {
    var norm = glMatrix.vec3.create(),
        ab  = glMatrix.vec3.create(),
        ac  = glMatrix.vec3.create(),
        cd  = glMatrix.vec3.create(),
        dist;

    ab = glMatrix.vec3.sub(ab, b, a);
    ac = glMatrix.vec3.sub(ac, c, a);
    glMatrix.vec3.cross(norm, ab, ac);
    if (glMatrix.vec3.length(norm) == 0) return undefined;
    glMatrix.vec3.sub(cd, d, c);
    dist = glMatrix.vec3.dot(norm, projVector(cd, norm));
    if(dist == 0) return 0;
    else return glMatrix.vec3.dot(norm, d) > 0 ? 1 : -1;
  }

  //Inputs: a (vec3), b (vec3), c (vec3), d (vec3)
  //Returns: intersection (vec3) or null if no intersection
  function getLineSegmentIntersection(a, b, c, d) {
    var ab = glMatrix.vec3.create(), cd = glMatrix.vec3.create(),
        p = glMatrix.vec3.create(), n = glMatrix.vec3.create();

    glMatrix.vec3.sub(ab, b, a);
    glMatrix.vec3.sub(cd, d, c);

    var s = solveParametricIntersection(a, ab, c, cd);
    if (!s) return null; 

    // check solution bounds
    if(s[0] < 0 || s[0] > 1 || s[1] < 0 || s[1] > 1) return null;

    glMatrix.vec3.scale(n, ab, s[0]);
    glMatrix.vec3.add(p, a, n);

    return p; // a + su
  }

  // point a extending in direction u, point b extending in direction v
  // returns null if lines are parallel or skew
  function solveParametricIntersection(a, u, b, v) {
    var ux = u[0], uy = u[1], uz = u[2],
        vx = -v[0], vy = -v[1], vz = -v[2],
        bx = b[0] - a[0], by = b[1] - a[1], bz = b[2] - a[2],
        ab = glMatrix.vec3.create(), ba = glMatrix.vec3.create(),
        n1 = glMatrix.vec3.create(), n2 = glMatrix.vec3.create(),
        diff = glMatrix.vec3.create(),
        s, t;

    // two normals coincide if lines line in same plane
    glMatrix.vec3.sub(ab, b, a);
    glMatrix.vec3.sub(ba, a, b);
    glMatrix.vec3.cross(n1, u, ab);
    glMatrix.vec3.cross(n2, v, ba);
    glMatrix.vec3.normalize(n1, n1);
    glMatrix.vec3.normalize(n2, n2);

    glMatrix.vec3.cross(diff, n1, n2);

    if (!(inDelta(glMatrix.vec3.length(diff), 0.0))) return null;

    var denom;

    if(ux*vy - vx*uy !== 0) { // solve for x and y coordinates
        denom = ux*vy - vx*uy;
        s = (bx*vy - vx*by)/(denom);
        t = (ux*by - bx*uy)/(denom);
        return [s, t];
    } else if (ux*vz - vx*uz !== 0) { // solve for x and z coordinates
        denom = ux*vz - vx*uz;
        s = (bx*vz - vx*bz)/(denom);
        t = (ux*bz - bx*uz)/(denom);
        return [s, t];
    } else if (uy*vz - vy*uz !== 0) { // solve for y and z coordinates
        denom = uy*vz - vy*uz;
        s = (by*vz - vy*bz)/(denom);
        t = (uy*bz - by*uz)/(denom);
        return [s, t];
    } else 
        return null; // lines are parallel or coincide
  }

  function getLineIntersection(a, b, c, d) {
    var ab = glMatrix.vec3.create(), cd = glMatrix.vec3.create(),
        p = glMatrix.vec3.create(), n = glMatrix.vec3.create(),
        s;

    glMatrix.vec3.sub(ab, b, a);
    glMatrix.vec3.sub(cd, d, c);

    s = solveParametricIntersection(a, ab, c, cd);
    if (!s) return null; 

    glMatrix.vec3.scale(n, ab, s[0]);
    glMatrix.vec3.add(p, a, n);

    return p;
  }

  //Purpose: Given three points on a triangle abc, compute the triangle circumcenter
  //by intersecting two perpendicular bisectors from two different sides, and
  //compute the radius of the circumcircle
  //Inputs: a (vec3), b (vec3), c (vec3)
  //Returns: On object of the form {circumcenter: vec3, R: float (radius)}
  function getTriangleCircumcenter(A, B, C) {
    var a = glMatrix.vec3.create(0), b = glMatrix.vec3.create(),
        _a_2,
        _b_2,
        _axb_2,
        axb = glMatrix.vec3.create(),
        t1 = glMatrix.vec3.create(), t2 = glMatrix.vec3.create(), t3 = glMatrix.vec3.create(),
        p = glMatrix.vec3.create(),
        r;

    glMatrix.vec3.sub(a, A, C);
    glMatrix.vec3.sub(b, B, C);
    glMatrix.vec3.cross(axb, a, b);
    _a_2 = glMatrix.vec3.length(a) * glMatrix.vec3.length(a);
    _b_2 = glMatrix.vec3.length(b) * glMatrix.vec3.length(b);
    _axb_2 = glMatrix.vec3.length(axb) * glMatrix.vec3.length(axb);

    glMatrix.vec3.scale(t1, b, _a_2);
    glMatrix.vec3.scale(t2, a, _b_2);
    glMatrix.vec3.sub(t3, t1, t2);
    glMatrix.vec3.cross(p, t3, axb);

    glMatrix.vec3.scale(p, p, 1/(2*_axb_2));

    glMatrix.vec3.add(p, p, C);
    r = glMatrix.vec3.dist(C, p);

    return {Circumcenter: p, Radius: r}; 
  }

  //Purpose: Given four points on a 3D tetrahedron, compute the circumsphere
  //by intersecting two perpendicular bisectors from two different triangles,
  //and compute the radius of the circumsphere
  //Inputs: a (vec3), b (vec3), c (vec3), d (vec3)
  //Returns: On object of the form {circumcenter: vec3, R: float (radius)}
  function getTetrahedronCircumsphere(a, b, c, d) {
    var n1 = glMatrix.vec3.create(), n2 = glMatrix.vec3.create(),
        f = glMatrix.vec3.create(), h = glMatrix.vec3.create(),
        ab = glMatrix.vec3.create(), ac = glMatrix.vec3.create(),
        bc = glMatrix.vec3.create(), bd = glMatrix.vec3.create(),
        p, r;

    glMatrix.vec3.sub(ab, b, a);
    glMatrix.vec3.sub(ac, c, a);
    glMatrix.vec3.sub(bc, c, b);
    glMatrix.vec3.sub(bd, d, b);

    glMatrix.vec3.cross(n1, ab, ac);
    glMatrix.vec3.cross(n2, bc, bd);
    
    var e = getTriangleCircumcenter(a, b, c).Circumcenter;
    var g = getTriangleCircumcenter(b, c, d).Circumcenter;

    glMatrix.vec3.add(f, e, n1);
    glMatrix.vec3.add(h, g, n2);

    p = getLineIntersection(e, f, g, h);
    r = glMatrix.vec3.dist(a, p);

    return {Circumcenter: p, Radius: r};
  }

  function inDelta(actual, expected) {
    return actual < expected + epsilon && actual > expected - epsilon;
  }

  var version = "0.0.1";

  exports.version = version;
  exports.projVector = projVector;
  exports.projPerpVector = projPerpVector;
  exports.getAngle = getAngle;
  exports.getTriangleArea = getTriangleArea;
  exports.getAboveOrBelow = getAboveOrBelow;
  exports.getLineSegmentIntersection = getLineSegmentIntersection;
  exports.solveParametricIntersection = solveParametricIntersection;
  exports.getLineIntersection = getLineIntersection;
  exports.getTriangleCircumcenter = getTriangleCircumcenter;
  exports.getTetrahedronCircumsphere = getTetrahedronCircumsphere;

}));